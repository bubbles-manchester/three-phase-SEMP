# Three Phase Bubble Code #

The date in the repo, is the date that the repo was created not the date of the latest commit.

The master branch should only be used for the latest stable code, any hotfixes that are required for the master code should be branched from the master code (and tracked remotely) using:

```
git checkout master
git checkout -b hotfix
git push -u origin hotfix
```

Once the hotfix is completed, there are two ways to merge into the master branch:

```
git checkout master
git pull
git pull --no-ff origin hotfix
```

or

```
git checkout master
git pull
git merge --no-ff hotfix
```

and push to the remote using `git push`. I am unsure of which way is the best. I would guess that it doesn't matter because that should create a merge commit, meaning the command `git branch --merged` should show which branches have been merged. The reason for the `--no-ff` is to create a merge commit, as otherwise when a branch is merged using fast forward no merge commit is created. Then the hotfix branch should be deleted using:

```
git push origin --delete hotfix
git branch -d hotfix
```

Any new features to be added to the code should have their own branch. For example, if we wish to add OpenMP to 2 subroutines precalciCG5 and calciCG5 then we create a branch from the master branch for the OpenMP additions, i.e.:

```
git checkout master
git checkout -b omp
git push -u origin omp
git checkout -b omp-precalciCG5 omp
git push -u origin omp-precalciCG5
```

Once the code for adding OpenMP to precalciCG5, the code is tested and verified (and pushed to the remote using `git push`) before being merged into the omp branch:

```
git checkout omp
git pull
git merge --no-ff omp-precalciCG5
git push
```

Note that this above will only merge from the local branch - to use the remote branch type: `git pull --no-ff origin [branch-name]`. This way it pulls the latest code from the remote branch. At this point, I am undecided whether to delete or keep the branches. For the moment I will keep them as it gives a nice history (although this may not be necessary, if a merge commit is used). This process is repeated for the second subroutine calciCG5. Once all of the features for OpenMP have been added, tested and verified (as well as pushed to the remote) we merge the OpenMP branch into the master branch. Note that it is possibly better to submit a pull request prior to doing this, however as Steve and I are currently the only two working on the code, it is unnecessary as we can simply send each other an email!

```
git checkout master
git pull
git pull --no-ff origin omp
git push
```

This model is to used for all features that need to be added.

If there comes a point, where the parent branch needs to be hotfixed then the hotfix branch is created from the parent branch. However, this results in the child branch being one commit behind it's parent. I am unsure of the best practice here. There are two options, either employ a git pull or a git merge. Given that git pull does a merge, it's probably better to use it. Therefore, I think the best option is the following: Assume the master branch has just been hotfixed, to include those changes into the feature-branch one does:

```
git checkout feature-branch
git pull --rebase origin master
```

However, for some reason, this then requires a `git pull` from the feature branch? I think that's because I have messed around quite substantially with the commit history. Hopefully that will fix itself once I've merged the jetmarkers branch into the master branch.
